import Link from "next/link";

export default function Menu() {
  return (
    <nav>
      <div className="menu-item">
        <ImagensMenu
          className="home"
          props={{
            urlimg:
              "https://cdn.icon-icons.com/icons2/3242/PNG/512/cabin_destination_house_winter_wood_icon_197559.png",
            legenda: "desenho de casa",
            classeimg: "homeimg",
            url: "/",
            classetexto: "hometxt",
            item: "Home",
          }}
        />
        <ImagensMenu
          className="timer"
          props={{
            urlimg:
              "https://cdn.icon-icons.com/icons2/517/PNG/512/clock_time_icon-icons.com_51107.png",
            legenda: "desenho de relógio",
            classeimg: "timerimg",
            url: "/pagina1",
            classetexto: "timertxt",
            item: "Timer",
          }}
        />
      </div>
      <div className="menu-item">
        <ImagensMenu
          className="relatorio"
          props={{
            urlimg:
              "https://cdn.icon-icons.com/icons2/4169/PNG/512/study_education_book_read_address_book_icon_261868.png",
            legenda: "desenho folhas de papel remetendo a um relatório",
            classeimg: "relatorioimg",
            url: "/pagina2",
            classetexto: "relatoriotxt",
            item: "Relatório",
          }}
        />
        <ImagensMenu
          className="login"
          props={{
            urlimg:
              "https://cdn.icon-icons.com/icons2/3609/PNG/512/climate_forecast_weather_night_starry_star_moon_icon_226632.png",
            legenda: "desenho lua minguante com duas estrelas a esquerda",
            classeimg: "loginimg",
            url: "/pagina3",
            classetexto: "logintxt",
            item: "Login",
          }}
        />
      </div>
    </nav>
  );
}

function ImagensMenu({ props }) {
  return (
    <Link href={props.url}>
      <div className="menu-item">
        <img
          src={props.urlimg}
          alt={props.legenda}
          className={props.classeimg}
        />
        <span className={props.classetexto}>{props.item}</span>
      </div>
    </Link>
  );
}
