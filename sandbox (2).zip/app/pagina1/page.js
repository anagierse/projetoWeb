"use client";

import React, { useState } from "react";
import Link from "next/link";
import Menu from "../components/Menu";
import { useSearchParams } from "next/navigation";

export default function Pagina1() {
  const [buttonText, setButtonText] = useState("Começar timer");
  const [buttonClicked, setButtonClicked] = useState(false);

  const Click = () => {
    if (buttonClicked) {
      setButtonText("Começar timer");
    } else {
      setButtonText("Parar timer");
    }
    setButtonClicked(!buttonClicked);
  };

  return (
    <section>
      <Menu />
      <div className="circuloMaior">
        <div className="circuloMenor">
          <button className="botaoTimer" onClick={Click}>
            {buttonText}
          </button>
        </div>
      </div>
    </section>
  );
}
